﻿using System;

namespace NRICValidator
{
    class Program
    {
        static void Main(string[] args)
        {
            // Get the user input
            Console.Write("Enter NRIC: ");
            string nric = Console.ReadLine();

            int len = nric.Length;

            // Test for the length of input
            if (len != 9)
            {
                Console.WriteLine("Invalid NRIC");
                return;
            }

            // Test for valid first character 
            char fCh = nric[0];

            if(fCh == 'S' || fCh == 'T' || fCh == 'F' || fCh == 'G')
            {
                // Further validation needed
                // 1st condition
                int[] weights = { 0, 2, 7, 6, 5, 4, 3, 2 };
                int sum = 0;

                // 2nd Condition
                for (int idx = 1; idx <= 7; idx = idx + 1)
                {
                    int ch = Convert.ToInt32(nric[idx] + "");
                    int weight = weights[idx];

                    sum = sum + ch * weight;
                }

                
                if (fCh == 'T' || fCh == 'G')
                {
                    sum = sum + 4;
                }

                // Get the remainder
                // 3rd Condition
                int rem = sum % 11;

                char[] lChars = new char[11];
                
                // 4th conditon
                if (fCh == 'S' || fCh == 'T')
                {
                    lChars[0] = 'J';
                    lChars[1] = 'Z';
                    lChars[2] = 'I';
                    lChars[3] = 'H';
                    lChars[4] = 'G';
                    lChars[5] = 'F';
                    lChars[6] = 'E';
                    lChars[7] = 'D';
                    lChars[8] = 'C';
                    lChars[9] = 'B';
                    lChars[10] = 'A';
                }
                
                if (fCh == 'F' || fCh == 'G')
                {
                    lChars[0] = 'X';
                    lChars[1] = 'W';
                    lChars[2] = 'U';
                    lChars[3] = 'T';
                    lChars[4] = 'R';
                    lChars[5] = 'Q';
                    lChars[6] = 'P';
                    lChars[7] = 'N';
                    lChars[8] = 'M';
                    lChars[9] = 'L';
                    lChars[10] = 'K';
                }

                char validLastChar = lChars[rem];

                char lCh = nric[8];

                if (lCh == validLastChar)
                {
                    Console.WriteLine("Valid NRIC");
                }
                else
                {
                    Console.WriteLine("Invalid NRIC");
                }

            }
            else
            {
                Console.WriteLine("Invalid NRIC");
                return;
            }
        }
    }
}